<?php
if(isset($_POST['zipcode'])){
    $zipcode = $_POST['zipcode'];
}else{
    $zipcode = 'PLXX0040';
}
$result = file_get_contents('http://weather.yahooapis.com/forecastrss?p=' . $zipcode . '&u=c');
$xml = simplexml_load_string($result);
//echo htmlspecialchars($result, ENT_QUOTES, 'UTF-8');
$xml->registerXPathNamespace('yweather', 'http://xml.weather.yahoo.com/ns/rss/1.0');
$location = $xml->channel->xpath('yweather:location');
if(!empty($location)){
    foreach($xml->channel->item as $item){
        $current = $item->xpath('yweather:condition');
        $forecast = $item->xpath('yweather:forecast');
        $current = $current[0];
        $output = <<<END
            <h1 style="margin-bottom: 0">Pogoda w mieście: {$location[0]['city']}, {$location[0]['region']}</h1>
            <small>{$current['date']}</small>
            <p>
	    <p>
	    <br>
            <span style="font-size:72px; font-weight:bold;">{$current['temp']}&deg;C</span>
            <br/>
            <img src="http://l.yimg.com/a/i/us/we/52/{$current['code']}.gif" style="vertical-align: middle;"/>&nbsp;
            {$current['text']}
            </p>
            <h2>Prognoza</h2>
            {$forecast[0]['day']} - {$forecast[0]['text']}. High: {$forecast[0]['high']} Low: {$forecast[0]['low']}
            <br/>
            {$forecast[1]['day']} - {$forecast[1]['text']}. High: {$forecast[1]['high']} Low: {$forecast[1]['low']}
            </p>
END;
    }
}else{
    $output = '<h1>Nie znaleziono kodu miasta<h1 />';
}
?>
<html>
<head>
<title>Weather</title>
<style>
body {
    font-family: Arial, Helvetica, sans-serif;
    font-size: 12px;
}
label {
    font-weight: bold;
}
</style>
</head>
<body>
<form method="POST" action="">
<label>Kod miasta:</label> <input type="text" name="zipcode" size="8" value="" /><br /><input type="submit" name="submit" value="Szukaj" />
</form>
<hr />
<?php echo $output; ?>
</body>
</html>
