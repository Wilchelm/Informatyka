<?php
defined('_JEXEC') or die('Acces Deny');
class modModuleHelper
{
	public static function saveData($liczba)
	{
		$$db=JFactory::getDBO();
		$query="INSERT INTO `#__joomla`(`liczba`) VALUES($liczba)";
		$db->setQuery($query);
		if($db->query())
		{
			return true;
		}
		else
		{
			return false;
		}
	}
}