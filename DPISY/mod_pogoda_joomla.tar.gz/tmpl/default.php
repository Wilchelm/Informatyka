<?php
defined('_JEXEC') or die('Access Deny');
?>

<form name="module" id="module" method="post">
<p>
<label form="name">Wpisz liczbę</label>
<input type="text" name="liczba" id="liczba"/>
</p>
<p>
<input type="submit" name="module_btn" id="module_btn" value="Wyślij"/>
</p>
</form>