#include "Dependencies\glew\glew.h"
#include "Dependencies\freeglut\freeglut.h"
#include "Dependencies\Simple OpenGL Image Library\src\SOIL.h"
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <iostream>
#include <windows.h>
#include <vector>
#include "Shader_Loader.h"

#define BUFFER_OFFSET(offset) ((void*)(offset))

using namespace Core;
GLuint program;
GLuint czasU;
GLuint perspectiveMatrixUnif;
GLuint modelToCameraMatrixUnif;
GLuint modelToRotateZMatrixUnif;
float modelToRotateZMatrix[16];
float perspectiveMatrix[16];
float modelToCameraMatrix[16];
float fFrustumScale = 1.0;
std::vector<float> kula;
GLuint vao;
GLUquadricObj *quadratic;
float rotatez = 0;

void RotateZ( float rotatez) {
	modelToRotateZMatrix[0] = cos(rotatez);
	modelToRotateZMatrix[1] = sin(rotatez);
	modelToRotateZMatrix[4] = -sin(rotatez);
	modelToRotateZMatrix[5] = cos(rotatez);
	modelToRotateZMatrix[10] = 1;
	modelToRotateZMatrix[15] = 1;
}

GLuint SolidSphere(float radius, int slices, int stacks)
{
	using namespace glm;
	using namespace std;

	const float pi = 3.1415926535897932384626433832795f;
	const float _2pi = 2.0f * pi;

	vector<vec4> positions;
	vector<vec4> normals;
	vector<vec2> textureCoords;

	for (int i = 0; i <= stacks; ++i)
	{
		// wspolrzedna tekstury v
		float V = i / (float)stacks;
		float phi = V * pi;

		for (int j = 0; j <= slices; ++j)
		{
			// wspolrzedna tekstury u
			float U = j / (float)slices;
			float theta = U * _2pi;

			float X = cos(theta) * sin(phi) ;
			float Y = cos(phi);
			float Z = sin(theta) * sin(phi);

			positions.push_back(vec4(X, Y, Z, 1.0) * radius);
			normals.push_back(vec4(X, Y, Z, 0.0));
			textureCoords.push_back(vec2(U, V));
		}
	}

	// bufor indeksow
	vector<GLuint> indicies;

	for (int i = 0; i < slices * stacks + slices; ++i)
	{
		indicies.push_back(i);
		indicies.push_back(i + slices + 1);
		indicies.push_back(i + slices);

		indicies.push_back(i + slices + 1);
		indicies.push_back(i);
		indicies.push_back(i + 1);
	}

	GLuint vao;
	glGenVertexArrays(1, &vao);
	glBindVertexArray(vao);

	GLuint vbos[4];
	glGenBuffers(4, vbos);

	glBindBuffer(GL_ARRAY_BUFFER, vbos[0]);
	glBufferData(GL_ARRAY_BUFFER, positions.size() * sizeof(vec4), positions.data(), GL_STATIC_DRAW);
	glVertexAttribPointer(0, 4, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));
	glEnableVertexAttribArray(0);

	glBindBuffer(GL_ARRAY_BUFFER, vbos[1]);
	glBufferData(GL_ARRAY_BUFFER, textureCoords.size() * sizeof(vec2), textureCoords.data(), GL_STATIC_DRAW);
	glVertexAttribPointer(1, 2, GL_FLOAT, GL_FALSE, 0, BUFFER_OFFSET(0));
	glEnableVertexAttribArray(1);

	glBindBuffer(GL_ARRAY_BUFFER, vbos[2]);
	glBufferData(GL_ARRAY_BUFFER, normals.size() * sizeof(vec4), normals.data(), GL_STATIC_DRAW);
	glVertexAttribPointer(2, 4, GL_FLOAT, GL_TRUE, 0, BUFFER_OFFSET(0));
	glEnableVertexAttribArray(2);

	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, vbos[3]);
	glBufferData(GL_ELEMENT_ARRAY_BUFFER, indicies.size() * sizeof(GLuint), indicies.data(), GL_STATIC_DRAW);

	glBindVertexArray(0);
	glBindBuffer(GL_ARRAY_BUFFER, 0);
	glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, 0);

	return vao;
}

GLuint LoadTexture(const std::string& file)
{
	GLuint textureId = SOIL_load_OGL_texture(file.c_str(), SOIL_LOAD_AUTO, SOIL_CREATE_NEW_ID, SOIL_FLAG_MIPMAPS);
	glBindTexture(GL_TEXTURE_2D, textureId);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR_MIPMAP_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_S, GL_REPEAT);
	glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_WRAP_T, GL_REPEAT);
	glBindTexture(GL_TEXTURE_2D, 0);

	return textureId;
}

void renderScene() {
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glClearColor(0.0, 1.0, 1.0, 0.0);

	//u�ywaj wprowadzone shadery
	glUseProgram(program);

	

	glBindVertexArray(vao);
	glRotatef(90.0f, 0.0f, 1.0f, 0.0f);

	glutSolidCone(10, 30, 30, 32);

	

	glLoadIdentity();
	
	//glDrawArrays(GL_TRIANGLES, 0, 36);
	//glDrawArrays(GL_TRIANGLE_STRIP, 0, kula.size());

	const int IndexArray1[] = { 0,1,2 };
	const int IndexArray2[] = { 0,2,3 };

	glUniform1f(czasU, glutGet(GLUT_ELAPSED_TIME) / 1000.0f);
	glScalef(1.0, 1.0, 1.0);
	int numIndicies = (32 * 32 + 32) * 6;
	glDrawElements(GL_TRIANGLES,numIndicies, GL_UNSIGNED_INT, BUFFER_OFFSET(0));

	RotateZ(rotatez);
	glUniformMatrix4fv(modelToRotateZMatrixUnif, 1, GL_FALSE, modelToRotateZMatrix);

	glutSwapBuffers();

	glutPostRedisplay();
}

void Przyciski(int key, int x, int y) {
	switch(key)
	{
	case GLUT_KEY_PAGE_UP : rotatez += 5; break;
	case GLUT_KEY_PAGE_DOWN : rotatez -= 5; break;
	}
	glutPostRedisplay();
}

void Init()
{
	glEnable(GL_DEPTH_TEST);
	Core::Shader_Loader shaderLoader;
	program = shaderLoader.CreateProgram("Vertex_Shader.glsl", "Fragment_Shader.glsl");

	const float vertexPositions[] = { //pierwsze ze slajdow
		0.25f, 0.25f, 0.0f, 1.0f,
		0.25f, -0.25f, 0.0, 1.0f,
		-0.25f, -0.25f, 0.0f, 1.0f,
		-0.25f, 0.25f, 0.0f, 1.0f,
	};

	


	const float vertexData[] = {
		0.25f, 0.25f, -1.25f, 1.0f,
		0.25f, -0.25f, -1.25f, 1.0f,
		-0.25f, 0.25f, -1.25f, 1.0f,

		0.25f, -0.25f, -1.25f, 1.0f,
		-0.25f, -0.25f, -1.25f, 1.0f,
		-0.25f, 0.25f, -1.25f, 1.0f,

		0.25f, 0.25f, -2.75f, 1.0f,
		-0.25f, 0.25f, -2.75f, 1.0f,
		0.25f, -0.25f, -2.75f, 1.0f,

		0.25f, -0.25f, -2.75f, 1.0f,
		-0.25f, 0.25f, -2.75f, 1.0f,
		-0.25f, -0.25f, -2.75f, 1.0f,

		-0.25f, 0.25f, -1.25f, 1.0f,
		-0.25f, -0.25f, -1.25f, 1.0f,
		-0.25f, -0.25f, -2.75f, 1.0f,

		-0.25f, 0.25f, -1.25f, 1.0f,
		-0.25f, -0.25f, -2.75f, 1.0f,
		-0.25f, 0.25f, -2.75f, 1.0f,

		0.25f, 0.25f, -1.25f, 1.0f,
		0.25f, -0.25f, -2.75f, 1.0f,
		0.25f, -0.25f, -1.25f, 1.0f,

		0.25f, 0.25f, -1.25f, 1.0f,
		0.25f, 0.25f, -2.75f, 1.0f,
		0.25f, -0.25f, -2.75f, 1.0f,

		0.25f, 0.25f, -2.75f, 1.0f,
		0.25f, 0.25f, -1.25f, 1.0f,
		-0.25f, 0.25f, -1.25f, 1.0f,

		0.25f, 0.25f, -2.75f, 1.0f,
		-0.25f, 0.25f, -1.25f, 1.0f,
		-0.25f, 0.25f, -2.75f, 1.0f,

		0.25f, -0.25f, -2.75f, 1.0f,
		-0.25f, -0.25f, -1.25f, 1.0f,
		0.25f, -0.25f, -1.25f, 1.0f,

		0.25f, -0.25f, -2.75f, 1.0f,
		-0.25f, -0.25f, -2.75f, 1.0f,
		-0.25f, -0.25f, -1.25f, 1.0f,




		0.0f, 0.0f, 1.0f, 1.0f,
		0.0f, 0.0f, 1.0f, 1.0f,
		0.0f, 0.0f, 1.0f, 1.0f,

		0.0f, 0.0f, 1.0f, 1.0f,
		0.0f, 0.0f, 1.0f, 1.0f,
		0.0f, 0.0f, 1.0f, 1.0f,

		0.8f, 0.8f, 0.8f, 1.0f,
		0.8f, 0.8f, 0.8f, 1.0f,
		0.8f, 0.8f, 0.8f, 1.0f,

		0.8f, 0.8f, 0.8f, 1.0f,
		0.8f, 0.8f, 0.8f, 1.0f,
		0.8f, 0.8f, 0.8f, 1.0f,

		0.0f, 1.0f, 0.0f, 1.0f,
		0.0f, 1.0f, 0.0f, 1.0f,
		0.0f, 1.0f, 0.0f, 1.0f,

		0.0f, 1.0f, 0.0f, 1.0f,
		0.0f, 1.0f, 0.0f, 1.0f,
		0.0f, 1.0f, 0.0f, 1.0f,

		0.5f, 0.5f, 0.0f, 1.0f,
		0.5f, 0.5f, 0.0f, 1.0f,
		0.5f, 0.5f, 0.0f, 1.0f,

		0.5f, 0.5f, 0.0f, 1.0f,
		0.5f, 0.5f, 0.0f, 1.0f,
		0.5f, 0.5f, 0.0f, 1.0f,

		1.0f, 0.0f, 0.0f, 1.0f,
		1.0f, 0.0f, 0.0f, 1.0f,
		1.0f, 0.0f, 0.0f, 1.0f,

		1.0f, 0.0f, 0.0f, 1.0f,
		1.0f, 0.0f, 0.0f, 1.0f,
		1.0f, 0.0f, 0.0f, 1.0f,

		0.0f, 1.0f, 1.0f, 1.0f,
		0.0f, 1.0f, 1.0f, 1.0f,
		0.0f, 1.0f, 1.0f, 1.0f,

		0.0f, 1.0f, 1.0f, 1.0f,
		0.0f, 1.0f, 1.0f, 1.0f,
		0.0f, 1.0f, 1.0f, 1.0f,

	};


	GLuint tex = LoadTexture("fish.dds");

	quadratic = gluNewQuadric();

	vao = SolidSphere(1,32,32);

	glBindVertexArray(vao);

	czasU = glGetUniformLocation(program, "czas");
	GLuint czasokresU = glGetUniformLocation(program, "czasokres");
	GLuint fragCzasokresU = glGetUniformLocation(program, "fragCzasokres");

	glEnable(GL_DEPTH_TEST);
	glDepthMask(GL_TRUE);
	glDepthFunc(GL_LEQUAL);
	glDepthRange(0.0f, 1.0f);
	glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
	glClearDepth(1.0f);
	glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);
	glFrontFace(GL_CW);

	size_t kolory=sizeof(vertexData) / 2;
	glEnableVertexAttribArray(1);
	glVertexAttribPointer(1, 4, GL_FLOAT, GL_FALSE, 0,(void*)kolory);

	perspectiveMatrixUnif = glGetUniformLocation(program, "perspectiveMatrix");
	float fzNear = 0.5f; float fzFar = 3.0f;
	memset(perspectiveMatrix, 0, sizeof(float) * 16); /*float [16]*/
	perspectiveMatrix[0] = fFrustumScale; /*const float = 1.0*/
	perspectiveMatrix[5] = fFrustumScale;
	perspectiveMatrix[10] = (fzFar + fzNear) / (fzNear - fzFar);
	perspectiveMatrix[14] = (2 * fzFar * fzNear) / (fzNear - fzFar);
	perspectiveMatrix[11] = -1.0f;

	modelToRotateZMatrixUnif = glGetUniformLocation(program, "modelToRotateZMatrix");
	memset(modelToRotateZMatrix, 0, sizeof(float) * 16); /*float [16]*/
	

	modelToCameraMatrixUnif = glGetUniformLocation(program, "modelToCameraMatrix");
	memset(modelToCameraMatrix, 0, sizeof(float) * 16); /*float [16]*/
	modelToCameraMatrix[0] = 0.15f;
	modelToCameraMatrix[5] = 0.15f;
	modelToCameraMatrix[10] = 0.15f;
	modelToCameraMatrix[14] = -0.5f;
	modelToCameraMatrix[15] = 1;

	


	glUseProgram(program);
	glBindTexture(GL_TEXTURE_2D, tex);
	glUniformMatrix4fv(perspectiveMatrixUnif, 1, GL_FALSE, perspectiveMatrix);
	glUniformMatrix4fv(modelToCameraMatrixUnif, 1, GL_FALSE, modelToCameraMatrix);
	glUniformMatrix4fv(modelToRotateZMatrixUnif, 1, GL_FALSE, modelToRotateZMatrix);


	//glUniform1f(czasokresU, 2.0f);
	//glUniform1f(fragCzasokresU, 10.0f);

}

void reshape(int w,int h)
{
	perspectiveMatrix[0] =fFrustumScale* (h / (float)w);
	perspectiveMatrix[5] =fFrustumScale;
	glUseProgram(program);
	glUniformMatrix4fv(perspectiveMatrixUnif, 1, GL_FALSE,perspectiveMatrix);
	glUseProgram(0);
	glViewport(0, 0, (GLsizei)w, (GLsizei)h);
}

void resize(int w, int h)
{
	if (w >= h)
		glViewport(0, 0, (GLsizei)h, (GLsizei)h);
	else
		glViewport(0, 0, (GLsizei)w, (GLsizei)w);
}

int main(int argc, char **argv)
{
	glutInit(&argc, argv);
	glutInitDisplayMode(GLUT_DEPTH | GLUT_DOUBLE | GLUT_RGBA);
	glutInitWindowPosition(200, 200);
	glutInitWindowSize(800, 600);
	glutCreateWindow("OpenGL Pierwsze Okno");
	glEnable(GL_DEPTH_TEST);
	/*glutDisplayFunc(renderScene);
	if (glewIsSupported("GL_VERSION_4_3"))
	{
	std::cout << "TAK" << std::endl;
	}
	else
	{
	std::cout << "Nie" << std::endl;
	}*/


	glewInit();
	Init();

	// rejestruj callbacks
	glutDisplayFunc(renderScene);
	glutSpecialFunc(Przyciski);
	glutReshapeFunc(reshape);
	glutReshapeFunc(resize);
	glutMainLoop();
	glDeleteProgram(program);


	return 0;
}