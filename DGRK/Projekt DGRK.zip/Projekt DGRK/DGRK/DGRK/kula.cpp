std::vector<float> kula;

or (int i = 0; i <= 40; i++)
{
	float lat0 = 3.14159265359 * (-0.5 + (float)(i - 1) / 40);
	float z0 = sin(lat0);
	float zr0 = cos(lat0);

	float lat1 = 3.14159265359 * (-0.5 + (float)i / 40);
	float z1 = sin(lat1);
	float zr1 = cos(lat1);

	for (int j = 0; j <= 40; j++)
	{
		float lng = 2 * 3.14159265359 * (float)(j - 1) / 40;
		float x = cos(lng);
		float y = sin(lng);

		kula.push_back(x * zr0); 
		kula.push_back(y * zr0); 
		kula.push_back(z0);      
		kula.push_back(1.0f); 

		kula.push_back(x * zr1); 
		kula.push_back(y * zr1); 
		kula.push_back(z1);      
		kula.push_back(1.0f); 
	}
}